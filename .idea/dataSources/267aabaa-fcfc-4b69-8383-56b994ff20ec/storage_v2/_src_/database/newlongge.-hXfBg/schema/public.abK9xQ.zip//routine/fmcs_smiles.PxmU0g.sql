create function fmcs_smiles(text)
  returns text
immutable
language sql
as $$
SELECT CAST( fmcs_smiles(CAST($1 AS CSTRING), CAST('' AS CSTRING)) AS text);
$$;

alter function fmcs_smiles(text)
  owner to newjianping;

